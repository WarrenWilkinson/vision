﻿This zipped file contains the following files:

*_meta.txt – contains the metadata for the data file, including general information, geography notes, definitions and footnotes.

*CSV_data.csv – contains the data in a comma delimited format
or
*TAB_data.csv – contains the data in a tab delimited format.

Geo_starting_row_CSV.csv
or
Geo_starting_row_TAB.csv
Contains the starting row number for each geography in the data file. Due to the number of records in the download file, some software packages might not be able to import the Census Profile for all geographies included in the selected geographic level. To assist users in finding data for their geographic area(s) of interest, this file shows the starting row number for each geography included in the data file. Some software packages allow you to specify a starting row number when importing the data. For example, the Text Import Wizard within Microsoft Excel includes an option to 'Start import at row:', and the Import Data Wizard in SAS includes an option for 'Data records start at record number:'.

Data file record layout (column headings):

"CENSUS_YEAR"
"GEO_CODE (POR)"
"GEO_LEVEL"
"GEO_NAME"
"GNR"
"DATA_QUALITY_FLAG"
"CSD_TYPE_NAME"
"ALT_GEO_CODE"
"DIM: Time leaving for work (7)"
"Member ID: Time leaving for work (7)"
"Notes: Time leaving for work (7)"
"DIM: Sex (3)"
"Member ID: Sex (3)"
"Notes: Sex (3)"
"DIM: Age (5)"
"Member ID: Age (5)"
"Notes: Age (5)"
"DIM: Main mode of commuting (10)"
"Member ID: Main mode of commuting (10)"
"Notes: Main mode of commuting (10)"
"Dim: Commuting duration (7): Member ID: [1]: Total - Commuting duration"
"Dim: Commuting duration (7): Member ID: [2]: Less than 15 minutes"
"Dim: Commuting duration (7): Member ID: [3]: 15 to 29 minutes"
"Dim: Commuting duration (7): Member ID: [4]: 30 to 44 minutes"
"Dim: Commuting duration (7): Member ID: [5]: 45 to 59 minutes"
"Dim: Commuting duration (7): Member ID: [6]: 60 minutes and over"
"Dim: Commuting duration (7): Member ID: [7]: Average commuting duration"