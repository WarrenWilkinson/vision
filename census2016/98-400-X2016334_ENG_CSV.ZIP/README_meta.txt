﻿This zipped file contains the following files:

*_meta.txt – contains the metadata for the data file, including general information, geography notes, definitions and footnotes.

*CSV_data.csv – contains the data in a comma delimited format
or
*TAB_data.csv – contains the data in a tab delimited format.

Geo_starting_row_CSV.csv
or
Geo_starting_row_TAB.csv
Contains the starting row number for each geography in the data file. Due to the number of records in the download file, some software packages might not be able to import the Census Profile for all geographies included in the selected geographic level. To assist users in finding data for their geographic area(s) of interest, this file shows the starting row number for each geography included in the data file. Some software packages allow you to specify a starting row number when importing the data. For example, the Text Import Wizard within Microsoft Excel includes an option to 'Start import at row:', and the Import Data Wizard in SAS includes an option for 'Data records start at record number:'.

Data file record layout (column headings):

"CENSUS_YEAR"
"GEO_CODE (POR)"
"GEO_LEVEL"
"GEO_NAME"
"GNR"
"DATA_QUALITY_FLAG"
"CSD_TYPE_NAME"
"ALT_GEO_CODE"
"DIM: Occupation - National Occupational Classification (NOC) 2016 (11)"
"Member ID: Occupation - National Occupational Classification (NOC) 2016 (11)"
"Notes: Occupation - National Occupational Classification (NOC) 2016 (11)"
"DIM: Sex (3)"
"Member ID: Sex (3)"
"Notes: Sex (3)"
"DIM: Industry - North American Industry Classification System (NAICS) 2012 (21)"
"Member ID: Industry - North American Industry Classification System (NAICS) 2012 (21)"
"Notes: Industry - North American Industry Classification System (NAICS) 2012 (21)"
"Dim: Main mode of commuting (10): Member ID: [1]: Total - Main mode of commuting (Note: 3)"
"Dim: Main mode of commuting (10): Member ID: [2]: Car, truck or van"
"Dim: Main mode of commuting (10): Member ID: [3]: Driver, alone"
"Dim: Main mode of commuting (10): Member ID: [4]: 2 or more persons shared the ride to work"
"Dim: Main mode of commuting (10): Member ID: [5]: Driver, with 1 or more passengers"
"Dim: Main mode of commuting (10): Member ID: [6]: Passenger, 2 or more persons in the vehicle"
"Dim: Main mode of commuting (10): Member ID: [7]: Sustainable transportation"
"Dim: Main mode of commuting (10): Member ID: [8]: Public transit"
"Dim: Main mode of commuting (10): Member ID: [9]: Active transport"
"Dim: Main mode of commuting (10): Member ID: [10]: Other method"