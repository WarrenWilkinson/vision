﻿This zipped file contains the following files:

*_meta.txt – contains the metadata for the data file, including general information, geography notes, definitions and footnotes.

*CSV_data.csv – contains the data in a comma delimited format
or
*TAB_data.csv – contains the data in a tab delimited format.

Geo_starting_row_CSV.csv
or
Geo_starting_row_TAB.csv
Contains the starting row number for each geography in the data file. Due to the number of records in the download file, some software packages might not be able to import the Census Profile for all geographies included in the selected geographic level. To assist users in finding data for their geographic area(s) of interest, this file shows the starting row number for each geography included in the data file. Some software packages allow you to specify a starting row number when importing the data. For example, the Text Import Wizard within Microsoft Excel includes an option to 'Start import at row:', and the Import Data Wizard in SAS includes an option for 'Data records start at record number:'.

Data file record layout (column headings):

"CENSUS_YEAR"
"GEO_CODE (POR)"
"GEO_LEVEL"
"GEO_NAME"
"GNR"
"DATA_QUALITY_FLAG"
"CSD_TYPE_NAME"
"ALT_GEO_CODE"
"DIM: Sex (3)"
"Member ID: Sex (3)"
"Notes: Sex (3)"
"DIM: Age (5)"
"Member ID: Age (5)"
"Notes: Age (5)"
"DIM: Main mode of commuting (10)"
"Member ID: Main mode of commuting (10)"
"Notes: Main mode of commuting (10)"
"Dim: Commuting destination (5): Member ID: [1]: Total - Commuting destination"
"Dim: Commuting destination (5): Member ID: [2]: Commute within census subdivision (CSD) of residence"
"Dim: Commuting destination (5): Member ID: [3]: Commute to a different census subdivision (CSD) within census division (CD) of residence"
"Dim: Commuting destination (5): Member ID: [4]: Commute to a different census subdivision (CSD) and census division (CD) within province or territory of residence"
"Dim: Commuting destination (5): Member ID: [5]: Commute to a different province or territory"